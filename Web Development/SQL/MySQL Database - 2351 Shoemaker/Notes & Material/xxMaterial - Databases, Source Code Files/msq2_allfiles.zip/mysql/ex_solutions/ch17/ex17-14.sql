SET GLOBAL  general_log = OFF;

SELECT @@general_log;