DELETE FROM invoice_line_items
WHERE invoice_id = 116;

DELETE FROM invoices
WHERE invoice_id = 116;
